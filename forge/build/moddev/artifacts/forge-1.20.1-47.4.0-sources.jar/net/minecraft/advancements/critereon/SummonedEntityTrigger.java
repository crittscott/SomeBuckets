package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.storage.loot.LootContext;

public class SummonedEntityTrigger extends SimpleCriterionTrigger<SummonedEntityTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("summoned_entity");

   public ResourceLocation getId() {
      return ID;
   }

   public SummonedEntityTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      ContextAwarePredicate contextawarepredicate = EntityPredicate.fromJson(json, "entity", deserializationContext);
      return new SummonedEntityTrigger.TriggerInstance(predicate, contextawarepredicate);
   }

   public void trigger(ServerPlayer player, Entity entity) {
      LootContext lootcontext = EntityPredicate.createContext(player, entity);
      this.trigger(player, (p_68265_) -> {
         return p_68265_.matches(lootcontext);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final ContextAwarePredicate entity;

      public TriggerInstance(ContextAwarePredicate player, ContextAwarePredicate entity) {
         super(SummonedEntityTrigger.ID, player);
         this.entity = entity;
      }

      public static SummonedEntityTrigger.TriggerInstance summonedEntity(EntityPredicate.Builder entityPredicateBuilder) {
         return new SummonedEntityTrigger.TriggerInstance(ContextAwarePredicate.ANY, EntityPredicate.wrap(entityPredicateBuilder.build()));
      }

      public boolean matches(LootContext lootContext) {
         return this.entity.matches(lootContext);
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.add("entity", this.entity.toJson(conditions));
         return jsonobject;
      }
   }
}

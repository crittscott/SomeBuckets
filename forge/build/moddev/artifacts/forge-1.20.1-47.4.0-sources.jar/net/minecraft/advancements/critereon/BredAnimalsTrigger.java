package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import javax.annotation.Nullable;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.level.storage.loot.LootContext;

public class BredAnimalsTrigger extends SimpleCriterionTrigger<BredAnimalsTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("bred_animals");

   public ResourceLocation getId() {
      return ID;
   }

   public BredAnimalsTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      ContextAwarePredicate contextawarepredicate = EntityPredicate.fromJson(json, "parent", deserializationContext);
      ContextAwarePredicate contextawarepredicate1 = EntityPredicate.fromJson(json, "partner", deserializationContext);
      ContextAwarePredicate contextawarepredicate2 = EntityPredicate.fromJson(json, "child", deserializationContext);
      return new BredAnimalsTrigger.TriggerInstance(predicate, contextawarepredicate, contextawarepredicate1, contextawarepredicate2);
   }

   public void trigger(ServerPlayer player, Animal parent, Animal partner, @Nullable AgeableMob child) {
      LootContext lootcontext = EntityPredicate.createContext(player, parent);
      LootContext lootcontext1 = EntityPredicate.createContext(player, partner);
      LootContext lootcontext2 = child != null ? EntityPredicate.createContext(player, child) : null;
      this.trigger(player, (p_18653_) -> {
         return p_18653_.matches(lootcontext, lootcontext1, lootcontext2);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final ContextAwarePredicate parent;
      private final ContextAwarePredicate partner;
      private final ContextAwarePredicate child;

      public TriggerInstance(ContextAwarePredicate player, ContextAwarePredicate parent, ContextAwarePredicate partner, ContextAwarePredicate child) {
         super(BredAnimalsTrigger.ID, player);
         this.parent = parent;
         this.partner = partner;
         this.child = child;
      }

      public static BredAnimalsTrigger.TriggerInstance bredAnimals() {
         return new BredAnimalsTrigger.TriggerInstance(ContextAwarePredicate.ANY, ContextAwarePredicate.ANY, ContextAwarePredicate.ANY, ContextAwarePredicate.ANY);
      }

      public static BredAnimalsTrigger.TriggerInstance bredAnimals(EntityPredicate.Builder childBuilder) {
         return new BredAnimalsTrigger.TriggerInstance(ContextAwarePredicate.ANY, ContextAwarePredicate.ANY, ContextAwarePredicate.ANY, EntityPredicate.wrap(childBuilder.build()));
      }

      public static BredAnimalsTrigger.TriggerInstance bredAnimals(EntityPredicate parent, EntityPredicate partner, EntityPredicate child) {
         return new BredAnimalsTrigger.TriggerInstance(ContextAwarePredicate.ANY, EntityPredicate.wrap(parent), EntityPredicate.wrap(partner), EntityPredicate.wrap(child));
      }

      public boolean matches(LootContext parentContext, LootContext partnerContext, @Nullable LootContext childContext) {
         if (this.child == ContextAwarePredicate.ANY || childContext != null && this.child.matches(childContext)) {
            return this.parent.matches(parentContext) && this.partner.matches(partnerContext) || this.parent.matches(partnerContext) && this.partner.matches(parentContext);
         } else {
            return false;
         }
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.add("parent", this.parent.toJson(conditions));
         jsonobject.add("partner", this.partner.toJson(conditions));
         jsonobject.add("child", this.child.toJson(conditions));
         return jsonobject;
      }
   }
}

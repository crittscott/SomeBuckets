package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.item.crafting.Recipe;

public class RecipeUnlockedTrigger extends SimpleCriterionTrigger<RecipeUnlockedTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("recipe_unlocked");

   public ResourceLocation getId() {
      return ID;
   }

   public RecipeUnlockedTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      ResourceLocation resourcelocation = new ResourceLocation(GsonHelper.getAsString(json, "recipe"));
      return new RecipeUnlockedTrigger.TriggerInstance(predicate, resourcelocation);
   }

   public void trigger(ServerPlayer player, Recipe<?> recipe) {
      this.trigger(player, (p_63723_) -> {
         return p_63723_.matches(recipe);
      });
   }

   public static RecipeUnlockedTrigger.TriggerInstance unlocked(ResourceLocation recipe) {
      return new RecipeUnlockedTrigger.TriggerInstance(ContextAwarePredicate.ANY, recipe);
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final ResourceLocation recipe;

      public TriggerInstance(ContextAwarePredicate player, ResourceLocation recipe) {
         super(RecipeUnlockedTrigger.ID, player);
         this.recipe = recipe;
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.addProperty("recipe", this.recipe.toString());
         return jsonobject;
      }

      public boolean matches(Recipe<?> recipe) {
         return this.recipe.equals(recipe.getId());
      }
   }
}

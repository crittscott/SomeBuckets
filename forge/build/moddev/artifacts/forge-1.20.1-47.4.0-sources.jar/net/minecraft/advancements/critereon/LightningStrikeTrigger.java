package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.level.storage.loot.LootContext;

public class LightningStrikeTrigger extends SimpleCriterionTrigger<LightningStrikeTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("lightning_strike");

   public ResourceLocation getId() {
      return ID;
   }

   public LightningStrikeTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      ContextAwarePredicate contextawarepredicate = EntityPredicate.fromJson(json, "lightning", deserializationContext);
      ContextAwarePredicate contextawarepredicate1 = EntityPredicate.fromJson(json, "bystander", deserializationContext);
      return new LightningStrikeTrigger.TriggerInstance(predicate, contextawarepredicate, contextawarepredicate1);
   }

   public void trigger(ServerPlayer player, LightningBolt lightning, List<Entity> nearbyEntities) {
      List<LootContext> list = nearbyEntities.stream().map((p_153390_) -> {
         return EntityPredicate.createContext(player, p_153390_);
      }).collect(Collectors.toList());
      LootContext lootcontext = EntityPredicate.createContext(player, lightning);
      this.trigger(player, (p_153402_) -> {
         return p_153402_.matches(lootcontext, list);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final ContextAwarePredicate lightning;
      private final ContextAwarePredicate bystander;

      public TriggerInstance(ContextAwarePredicate player, ContextAwarePredicate lightning, ContextAwarePredicate bystander) {
         super(LightningStrikeTrigger.ID, player);
         this.lightning = lightning;
         this.bystander = bystander;
      }

      public static LightningStrikeTrigger.TriggerInstance lighthingStrike(EntityPredicate lightning, EntityPredicate bystander) {
         return new LightningStrikeTrigger.TriggerInstance(ContextAwarePredicate.ANY, EntityPredicate.wrap(lightning), EntityPredicate.wrap(bystander));
      }

      public boolean matches(LootContext playerContext, List<LootContext> entityContexts) {
         if (!this.lightning.matches(playerContext)) {
            return false;
         } else {
            return this.bystander == ContextAwarePredicate.ANY || !entityContexts.stream().noneMatch(this.bystander::matches);
         }
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.add("lightning", this.lightning.toJson(conditions));
         jsonobject.add("bystander", this.bystander.toJson(conditions));
         return jsonobject;
      }
   }
}

package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.util.Arrays;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.level.storage.loot.predicates.LocationCheck;
import net.minecraft.world.level.storage.loot.predicates.LootItemBlockStatePropertyCondition;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraft.world.level.storage.loot.predicates.MatchTool;

public class ItemUsedOnLocationTrigger extends SimpleCriterionTrigger<ItemUsedOnLocationTrigger.TriggerInstance> {
   final ResourceLocation id;

   public ItemUsedOnLocationTrigger(ResourceLocation id) {
      this.id = id;
   }

   public ResourceLocation getId() {
      return this.id;
   }

   public ItemUsedOnLocationTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      ContextAwarePredicate contextawarepredicate = ContextAwarePredicate.fromElement("location", deserializationContext, json.get("location"), LootContextParamSets.ADVANCEMENT_LOCATION);
      if (contextawarepredicate == null) {
         throw new JsonParseException("Failed to parse 'location' field");
      } else {
         return new ItemUsedOnLocationTrigger.TriggerInstance(this.id, predicate, contextawarepredicate);
      }
   }

   public void trigger(ServerPlayer player, BlockPos pos, ItemStack stack) {
      ServerLevel serverlevel = player.serverLevel();
      BlockState blockstate = serverlevel.getBlockState(pos);
      LootParams lootparams = (new LootParams.Builder(serverlevel)).withParameter(LootContextParams.ORIGIN, pos.getCenter()).withParameter(LootContextParams.THIS_ENTITY, player).withParameter(LootContextParams.BLOCK_STATE, blockstate).withParameter(LootContextParams.TOOL, stack).create(LootContextParamSets.ADVANCEMENT_LOCATION);
      LootContext lootcontext = (new LootContext.Builder(lootparams)).create((ResourceLocation)null);
      this.trigger(player, (p_286596_) -> {
         return p_286596_.matches(lootcontext);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final ContextAwarePredicate location;

      public TriggerInstance(ResourceLocation criterion, ContextAwarePredicate player, ContextAwarePredicate location) {
         super(criterion, player);
         this.location = location;
      }

      public static ItemUsedOnLocationTrigger.TriggerInstance placedBlock(Block block) {
         ContextAwarePredicate contextawarepredicate = ContextAwarePredicate.create(LootItemBlockStatePropertyCondition.hasBlockStateProperties(block).build());
         return new ItemUsedOnLocationTrigger.TriggerInstance(CriteriaTriggers.PLACED_BLOCK.id, ContextAwarePredicate.ANY, contextawarepredicate);
      }

      public static ItemUsedOnLocationTrigger.TriggerInstance placedBlock(LootItemCondition.Builder... conditions) {
         ContextAwarePredicate contextawarepredicate = ContextAwarePredicate.create(Arrays.stream(conditions).map(LootItemCondition.Builder::build).toArray((p_286827_) -> {
            return new LootItemCondition[p_286827_];
         }));
         return new ItemUsedOnLocationTrigger.TriggerInstance(CriteriaTriggers.PLACED_BLOCK.id, ContextAwarePredicate.ANY, contextawarepredicate);
      }

      private static ItemUsedOnLocationTrigger.TriggerInstance itemUsedOnLocation(LocationPredicate.Builder locationPredicate, ItemPredicate.Builder itemPredicate, ResourceLocation criterion) {
         ContextAwarePredicate contextawarepredicate = ContextAwarePredicate.create(LocationCheck.checkLocation(locationPredicate).build(), MatchTool.toolMatches(itemPredicate).build());
         return new ItemUsedOnLocationTrigger.TriggerInstance(criterion, ContextAwarePredicate.ANY, contextawarepredicate);
      }

      public static ItemUsedOnLocationTrigger.TriggerInstance itemUsedOnBlock(LocationPredicate.Builder locationPredicate, ItemPredicate.Builder itemPredicate) {
         return itemUsedOnLocation(locationPredicate, itemPredicate, CriteriaTriggers.ITEM_USED_ON_BLOCK.id);
      }

      public static ItemUsedOnLocationTrigger.TriggerInstance allayDropItemOnBlock(LocationPredicate.Builder locationPredicate, ItemPredicate.Builder itemPredicate) {
         return itemUsedOnLocation(locationPredicate, itemPredicate, CriteriaTriggers.ALLAY_DROP_ITEM_ON_BLOCK.id);
      }

      public boolean matches(LootContext context) {
         return this.location.matches(context);
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.add("location", this.location.toJson(conditions));
         return jsonobject;
      }
   }
}

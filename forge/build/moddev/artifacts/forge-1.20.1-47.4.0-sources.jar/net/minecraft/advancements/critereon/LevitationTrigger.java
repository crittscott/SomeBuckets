package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

public class LevitationTrigger extends SimpleCriterionTrigger<LevitationTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("levitation");

   public ResourceLocation getId() {
      return ID;
   }

   public LevitationTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      DistancePredicate distancepredicate = DistancePredicate.fromJson(json.get("distance"));
      MinMaxBounds.Ints minmaxbounds$ints = MinMaxBounds.Ints.fromJson(json.get("duration"));
      return new LevitationTrigger.TriggerInstance(predicate, distancepredicate, minmaxbounds$ints);
   }

   public void trigger(ServerPlayer player, Vec3 startPos, int duration) {
      this.trigger(player, (p_49124_) -> {
         return p_49124_.matches(player, startPos, duration);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final DistancePredicate distance;
      private final MinMaxBounds.Ints duration;

      public TriggerInstance(ContextAwarePredicate player, DistancePredicate distance, MinMaxBounds.Ints duration) {
         super(LevitationTrigger.ID, player);
         this.distance = distance;
         this.duration = duration;
      }

      public static LevitationTrigger.TriggerInstance levitated(DistancePredicate distance) {
         return new LevitationTrigger.TriggerInstance(ContextAwarePredicate.ANY, distance, MinMaxBounds.Ints.ANY);
      }

      public boolean matches(ServerPlayer player, Vec3 startPos, int duration) {
         if (!this.distance.matches(startPos.x, startPos.y, startPos.z, player.getX(), player.getY(), player.getZ())) {
            return false;
         } else {
            return this.duration.matches(duration);
         }
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.add("distance", this.distance.serializeToJson());
         jsonobject.add("duration", this.duration.serializeToJson());
         return jsonobject;
      }
   }
}

package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

public class ItemDurabilityTrigger extends SimpleCriterionTrigger<ItemDurabilityTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("item_durability_changed");

   public ResourceLocation getId() {
      return ID;
   }

   public ItemDurabilityTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      ItemPredicate itempredicate = ItemPredicate.fromJson(json.get("item"));
      MinMaxBounds.Ints minmaxbounds$ints = MinMaxBounds.Ints.fromJson(json.get("durability"));
      MinMaxBounds.Ints minmaxbounds$ints1 = MinMaxBounds.Ints.fromJson(json.get("delta"));
      return new ItemDurabilityTrigger.TriggerInstance(predicate, itempredicate, minmaxbounds$ints, minmaxbounds$ints1);
   }

   public void trigger(ServerPlayer player, ItemStack item, int newDurability) {
      this.trigger(player, (p_43676_) -> {
         return p_43676_.matches(item, newDurability);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final ItemPredicate item;
      private final MinMaxBounds.Ints durability;
      private final MinMaxBounds.Ints delta;

      public TriggerInstance(ContextAwarePredicate player, ItemPredicate item, MinMaxBounds.Ints durability, MinMaxBounds.Ints delta) {
         super(ItemDurabilityTrigger.ID, player);
         this.item = item;
         this.durability = durability;
         this.delta = delta;
      }

      public static ItemDurabilityTrigger.TriggerInstance changedDurability(ItemPredicate item, MinMaxBounds.Ints durability) {
         return changedDurability(ContextAwarePredicate.ANY, item, durability);
      }

      public static ItemDurabilityTrigger.TriggerInstance changedDurability(ContextAwarePredicate player, ItemPredicate item, MinMaxBounds.Ints durability) {
         return new ItemDurabilityTrigger.TriggerInstance(player, item, durability, MinMaxBounds.Ints.ANY);
      }

      public boolean matches(ItemStack item, int durability) {
         if (!this.item.matches(item)) {
            return false;
         } else if (!this.durability.matches(item.getMaxDamage() - durability)) {
            return false;
         } else {
            return this.delta.matches(item.getDamageValue() - durability);
         }
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.add("item", this.item.serializeToJson());
         jsonobject.add("durability", this.durability.serializeToJson());
         jsonobject.add("delta", this.delta.serializeToJson());
         return jsonobject;
      }
   }
}

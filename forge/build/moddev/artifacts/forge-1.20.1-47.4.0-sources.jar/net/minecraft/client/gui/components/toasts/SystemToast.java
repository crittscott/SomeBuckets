package net.minecraft.client.gui.components.toasts;

import com.google.common.collect.ImmutableList;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class SystemToast implements Toast {
   private static final int MAX_LINE_SIZE = 200;
   private static final int LINE_SPACING = 12;
   private static final int MARGIN = 10;
   private final SystemToast.SystemToastIds id;
   private Component title;
   private List<FormattedCharSequence> messageLines;
   private long lastChanged;
   private boolean changed;
   private final int width;

   public SystemToast(SystemToast.SystemToastIds id, Component title, @Nullable Component message) {
      this(id, title, nullToEmpty(message), Math.max(160, 30 + Math.max(Minecraft.getInstance().font.width(title), message == null ? 0 : Minecraft.getInstance().font.width(message))));
   }

   public static SystemToast multiline(Minecraft minecraft, SystemToast.SystemToastIds id, Component title, Component message) {
      Font font = minecraft.font;
      List<FormattedCharSequence> list = font.split(message, 200);
      int i = Math.max(200, list.stream().mapToInt(font::width).max().orElse(200));
      return new SystemToast(id, title, list, i + 30);
   }

   private SystemToast(SystemToast.SystemToastIds id, Component title, List<FormattedCharSequence> messageLines, int width) {
      this.id = id;
      this.title = title;
      this.messageLines = messageLines;
      this.width = width;
   }

   private static ImmutableList<FormattedCharSequence> nullToEmpty(@Nullable Component message) {
      return message == null ? ImmutableList.of() : ImmutableList.of(message.getVisualOrderText());
   }

   public int width() {
      return this.width;
   }

   public int height() {
      return 20 + Math.max(this.messageLines.size(), 1) * 12;
   }

   public Toast.Visibility render(GuiGraphics guiGraphics, ToastComponent toastComponent, long timeSinceLastVisible) {
      if (this.changed) {
         this.lastChanged = timeSinceLastVisible;
         this.changed = false;
      }

      int i = this.width();
      if (i == 160 && this.messageLines.size() <= 1) {
         guiGraphics.blit(TEXTURE, 0, 0, 0, 64, i, this.height());
      } else {
         int j = this.height();
         int k = 28;
         int l = Math.min(4, j - 28);
         this.renderBackgroundRow(guiGraphics, toastComponent, i, 0, 0, 28);

         for(int i1 = 28; i1 < j - l; i1 += 10) {
            this.renderBackgroundRow(guiGraphics, toastComponent, i, 16, i1, Math.min(16, j - i1 - l));
         }

         this.renderBackgroundRow(guiGraphics, toastComponent, i, 32 - l, j - l, l);
      }

      if (this.messageLines == null) {
         guiGraphics.drawString(toastComponent.getMinecraft().font, this.title, 18, 12, -256, false);
      } else {
         guiGraphics.drawString(toastComponent.getMinecraft().font, this.title, 18, 7, -256, false);

         for(int j1 = 0; j1 < this.messageLines.size(); ++j1) {
            guiGraphics.drawString(toastComponent.getMinecraft().font, this.messageLines.get(j1), 18, 18 + j1 * 12, -1, false);
         }
      }

      return (double)(timeSinceLastVisible - this.lastChanged) < (double)this.id.displayTime * toastComponent.getNotificationDisplayTimeMultiplier() ? Toast.Visibility.SHOW : Toast.Visibility.HIDE;
   }

   private void renderBackgroundRow(GuiGraphics guiGraphics, ToastComponent toastComponent, int width, int p_282371_, int p_283613_, int p_282880_) {
      int i = p_282371_ == 0 ? 20 : 5;
      int j = Math.min(60, width - i);
      guiGraphics.blit(TEXTURE, 0, p_283613_, 0, 64 + p_282371_, i, p_282880_);

      for(int k = i; k < width - j; k += 64) {
         guiGraphics.blit(TEXTURE, k, p_283613_, 32, 64 + p_282371_, Math.min(64, width - k - j), p_282880_);
      }

      guiGraphics.blit(TEXTURE, width - j, p_283613_, 160 - j, 64 + p_282371_, j, p_282880_);
   }

   public void reset(Component title, @Nullable Component message) {
      this.title = title;
      this.messageLines = nullToEmpty(message);
      this.changed = true;
   }

   public SystemToast.SystemToastIds getToken() {
      return this.id;
   }

   public static void add(ToastComponent toastComponent, SystemToast.SystemToastIds id, Component title, @Nullable Component message) {
      toastComponent.addToast(new SystemToast(id, title, message));
   }

   public static void addOrUpdate(ToastComponent toastComponent, SystemToast.SystemToastIds id, Component title, @Nullable Component message) {
      SystemToast systemtoast = toastComponent.getToast(SystemToast.class, id);
      if (systemtoast == null) {
         add(toastComponent, id, title, message);
      } else {
         systemtoast.reset(title, message);
      }

   }

   public static void onWorldAccessFailure(Minecraft minecraft, String message) {
      add(minecraft.getToasts(), SystemToast.SystemToastIds.WORLD_ACCESS_FAILURE, Component.translatable("selectWorld.access_failure"), Component.literal(message));
   }

   public static void onWorldDeleteFailure(Minecraft minecraft, String message) {
      add(minecraft.getToasts(), SystemToast.SystemToastIds.WORLD_ACCESS_FAILURE, Component.translatable("selectWorld.delete_failure"), Component.literal(message));
   }

   public static void onPackCopyFailure(Minecraft minecraft, String message) {
      add(minecraft.getToasts(), SystemToast.SystemToastIds.PACK_COPY_FAILURE, Component.translatable("pack.copyFailure"), Component.literal(message));
   }

   @OnlyIn(Dist.CLIENT)
   public static enum SystemToastIds {
      TUTORIAL_HINT,
      NARRATOR_TOGGLE,
      WORLD_BACKUP,
      PACK_LOAD_FAILURE,
      WORLD_ACCESS_FAILURE,
      PACK_COPY_FAILURE,
      PERIODIC_NOTIFICATION,
      UNSECURE_SERVER_WARNING(10000L);

      final long displayTime;

      private SystemToastIds(long displayTime) {
         this.displayTime = displayTime;
      }

      private SystemToastIds() {
         this(5000L);
      }
   }
}

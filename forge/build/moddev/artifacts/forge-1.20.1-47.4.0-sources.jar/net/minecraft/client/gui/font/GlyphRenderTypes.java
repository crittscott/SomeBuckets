package net.minecraft.client.gui.font;

import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public record GlyphRenderTypes(RenderType normal, RenderType seeThrough, RenderType polygonOffset) {
   public static GlyphRenderTypes createForIntensityTexture(ResourceLocation id) {
      return new GlyphRenderTypes(RenderType.textIntensity(id), RenderType.textIntensitySeeThrough(id), RenderType.textIntensityPolygonOffset(id));
   }

   public static GlyphRenderTypes createForColorTexture(ResourceLocation id) {
      return new GlyphRenderTypes(RenderType.text(id), RenderType.textSeeThrough(id), RenderType.textPolygonOffset(id));
   }

   public RenderType select(Font.DisplayMode displayMode) {
      RenderType rendertype;
      switch (displayMode) {
         case NORMAL:
            rendertype = this.normal;
            break;
         case SEE_THROUGH:
            rendertype = this.seeThrough;
            break;
         case POLYGON_OFFSET:
            rendertype = this.polygonOffset;
            break;
         default:
            throw new IncompatibleClassChangeError();
      }

      return rendertype;
   }
}

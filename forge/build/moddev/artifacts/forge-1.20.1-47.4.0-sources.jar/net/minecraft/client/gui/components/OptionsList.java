package net.minecraft.client.gui.components;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.Options;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.narration.NarratableEntry;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class OptionsList extends ContainerObjectSelectionList<OptionsList.Entry> {
   public OptionsList(Minecraft minecraft, int width, int height, int y0, int y1, int itemHeight) {
      super(minecraft, width, height, y0, y1, itemHeight);
      this.centerListVertically = false;
   }

   public int addBig(OptionInstance<?> option) {
      return this.addEntry(OptionsList.Entry.big(this.minecraft.options, this.width, option));
   }

   public void addSmall(OptionInstance<?> leftOption, @Nullable OptionInstance<?> rightOption) {
      this.addEntry(OptionsList.Entry.small(this.minecraft.options, this.width, leftOption, rightOption));
   }

   public void addSmall(OptionInstance<?>[] options) {
      for(int i = 0; i < options.length; i += 2) {
         this.addSmall(options[i], i < options.length - 1 ? options[i + 1] : null);
      }

   }

   public int getRowWidth() {
      return 400;
   }

   protected int getScrollbarPosition() {
      return super.getScrollbarPosition() + 32;
   }

   @Nullable
   public AbstractWidget findOption(OptionInstance<?> option) {
      for(OptionsList.Entry optionslist$entry : this.children()) {
         AbstractWidget abstractwidget = optionslist$entry.options.get(option);
         if (abstractwidget != null) {
            return abstractwidget;
         }
      }

      return null;
   }

   public Optional<AbstractWidget> getMouseOver(double mouseX, double mouseY) {
      for(OptionsList.Entry optionslist$entry : this.children()) {
         for(AbstractWidget abstractwidget : optionslist$entry.children) {
            if (abstractwidget.isMouseOver(mouseX, mouseY)) {
               return Optional.of(abstractwidget);
            }
         }
      }

      return Optional.empty();
   }

   @OnlyIn(Dist.CLIENT)
   protected static class Entry extends ContainerObjectSelectionList.Entry<OptionsList.Entry> {
      final Map<OptionInstance<?>, AbstractWidget> options;
      final List<AbstractWidget> children;

      private Entry(Map<OptionInstance<?>, AbstractWidget> options) {
         this.options = options;
         this.children = ImmutableList.copyOf(options.values());
      }

      public static OptionsList.Entry big(Options options, int guiWidth, OptionInstance<?> option) {
         return new OptionsList.Entry(ImmutableMap.of(option, option.createButton(options, guiWidth / 2 - 155, 0, 310)));
      }

      public static OptionsList.Entry small(Options options, int guiWidth, OptionInstance<?> leftOption, @Nullable OptionInstance<?> rightOption) {
         AbstractWidget abstractwidget = leftOption.createButton(options, guiWidth / 2 - 155, 0, 150);
         return rightOption == null ? new OptionsList.Entry(ImmutableMap.of(leftOption, abstractwidget)) : new OptionsList.Entry(ImmutableMap.of(leftOption, abstractwidget, rightOption, rightOption.createButton(options, guiWidth / 2 - 155 + 160, 0, 150)));
      }

      public void render(GuiGraphics guiGraphics, int index, int top, int left, int width, int height, int mouseX, int mouseY, boolean hovering, float partialTick) {
         this.children.forEach((p_280776_) -> {
            p_280776_.setY(top);
            p_280776_.render(guiGraphics, mouseX, mouseY, partialTick);
         });
      }

      public List<? extends GuiEventListener> children() {
         return this.children;
      }

      public List<? extends NarratableEntry> narratables() {
         return this.children;
      }
   }
}

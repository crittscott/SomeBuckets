package com.mojang.realmsclient.gui;

import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public interface ErrorCallback {
   void error(Component error);

   default void error(String error) {
      this.error(Component.literal(error));
   }
}

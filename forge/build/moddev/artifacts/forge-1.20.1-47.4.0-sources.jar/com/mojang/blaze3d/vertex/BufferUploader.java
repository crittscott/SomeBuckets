package com.mojang.blaze3d.vertex;

import com.mojang.blaze3d.systems.RenderSystem;
import javax.annotation.Nullable;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class BufferUploader {
   @Nullable
   private static VertexBuffer lastImmediateBuffer;

   public static void reset() {
      if (lastImmediateBuffer != null) {
         invalidate();
         VertexBuffer.unbind();
      }

   }

   public static void invalidate() {
      lastImmediateBuffer = null;
   }

   public static void drawWithShader(BufferBuilder.RenderedBuffer buffer) {
      if (!RenderSystem.isOnRenderThreadOrInit()) {
         RenderSystem.recordRenderCall(() -> {
            _drawWithShader(buffer);
         });
      } else {
         _drawWithShader(buffer);
      }

   }

   private static void _drawWithShader(BufferBuilder.RenderedBuffer buffer) {
      VertexBuffer vertexbuffer = upload(buffer);
      if (vertexbuffer != null) {
         vertexbuffer.drawWithShader(RenderSystem.getModelViewMatrix(), RenderSystem.getProjectionMatrix(), RenderSystem.getShader());
      }

   }

   public static void draw(BufferBuilder.RenderedBuffer buffer) {
      VertexBuffer vertexbuffer = upload(buffer);
      if (vertexbuffer != null) {
         vertexbuffer.draw();
      }

   }

   @Nullable
   private static VertexBuffer upload(BufferBuilder.RenderedBuffer buffer) {
      RenderSystem.assertOnRenderThread();
      if (buffer.isEmpty()) {
         buffer.release();
         return null;
      } else {
         VertexBuffer vertexbuffer = bindImmediateBuffer(buffer.drawState().format());
         vertexbuffer.upload(buffer);
         return vertexbuffer;
      }
   }

   private static VertexBuffer bindImmediateBuffer(VertexFormat format) {
      VertexBuffer vertexbuffer = format.getImmediateDrawVertexBuffer();
      bindImmediateBuffer(vertexbuffer);
      return vertexbuffer;
   }

   private static void bindImmediateBuffer(VertexBuffer buffer) {
      if (buffer != lastImmediateBuffer) {
         buffer.bind();
         lastImmediateBuffer = buffer;
      }

   }
}

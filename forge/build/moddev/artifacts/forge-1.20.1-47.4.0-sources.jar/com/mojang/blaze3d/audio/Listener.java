package com.mojang.blaze3d.audio;

import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Vector3f;
import org.lwjgl.openal.AL10;

/**
 * The Listener class represents the listener in a 3D audio environment.
 *
 * The listener's position and orientation determine how sounds are perceived by the listener.
 */
@OnlyIn(Dist.CLIENT)
public class Listener {
   private float gain = 1.0F;
   private Vec3 position = Vec3.ZERO;

   /**
    * Sets the listener's position.
    *
    * @param position A Vec3 representing the listener's position in 3D space.
    */
   public void setListenerPosition(Vec3 position) {
      this.position = position;
      AL10.alListener3f(4100, (float)position.x, (float)position.y, (float)position.z);
   }

   public Vec3 getListenerPosition() {
      return this.position;
   }

   /**
    * Sets the listener's orientation.
    *
    * @param clientViewVector The view vector indicating the direction the listener
    *                         is facing.
    * @param viewVectorRaised The up vector indicating the listener's "up" direction.
    */
   public void setListenerOrientation(Vector3f clientViewVector, Vector3f viewVectorRaised) {
      AL10.alListenerfv(4111, new float[]{clientViewVector.x(), clientViewVector.y(), clientViewVector.z(), viewVectorRaised.x(), viewVectorRaised.y(), viewVectorRaised.z()});
   }

   /**
    * Sets the listener's gain.
    *
    * @param gain The gain to set for the listener.
    */
   public void setGain(float gain) {
      AL10.alListenerf(4106, gain);
      this.gain = gain;
   }

   public float getGain() {
      return this.gain;
   }

   public void reset() {
      this.setListenerPosition(Vec3.ZERO);
      this.setListenerOrientation(new Vector3f(0.0F, 0.0F, -1.0F), new Vector3f(0.0F, 1.0F, 0.0F));
   }
}

package com.mojang.blaze3d.vertex;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.core.Vec3i;
import net.minecraft.util.FastColor;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryStack;

@OnlyIn(Dist.CLIENT)
public interface VertexConsumer {
   VertexConsumer vertex(double x, double y, double z);

   VertexConsumer color(int red, int green, int blue, int alpha);

   VertexConsumer uv(float u, float v);

   VertexConsumer overlayCoords(int u, int v);

   VertexConsumer uv2(int u, int v);

   VertexConsumer normal(float x, float y, float z);

   void endVertex();

   default void vertex(float x, float y, float z, float red, float green, float blue, float alpha, float texU, float texV, int overlayUV, int lightmapUV, float normalX, float normalY, float normalZ) {
      this.vertex((double)x, (double)y, (double)z);
      this.color(red, green, blue, alpha);
      this.uv(texU, texV);
      this.overlayCoords(overlayUV);
      this.uv2(lightmapUV);
      this.normal(normalX, normalY, normalZ);
      this.endVertex();
   }

   void defaultColor(int defaultR, int defaultG, int defaultB, int defaultA);

   void unsetDefaultColor();

   default VertexConsumer color(float red, float green, float blue, float alpha) {
      return this.color((int)(red * 255.0F), (int)(green * 255.0F), (int)(blue * 255.0F), (int)(alpha * 255.0F));
   }

   default VertexConsumer color(int colorARGB) {
      return this.color(FastColor.ARGB32.red(colorARGB), FastColor.ARGB32.green(colorARGB), FastColor.ARGB32.blue(colorARGB), FastColor.ARGB32.alpha(colorARGB));
   }

   default VertexConsumer uv2(int lightmapUV) {
      return this.uv2(lightmapUV & '\uffff', lightmapUV >> 16 & '\uffff');
   }

   default VertexConsumer overlayCoords(int overlayUV) {
      return this.overlayCoords(overlayUV & '\uffff', overlayUV >> 16 & '\uffff');
   }

   default void putBulkData(PoseStack.Pose poseEntry, BakedQuad quad, float red, float green, float blue, int combinedLight, int combinedOverlay) {
      this.putBulkData(poseEntry, quad, new float[]{1.0F, 1.0F, 1.0F, 1.0F}, red, green, blue, new int[]{combinedLight, combinedLight, combinedLight, combinedLight}, combinedOverlay, false);
   }

   default void putBulkData(PoseStack.Pose poseEntry, BakedQuad quad, float[] colorMuls, float red, float green, float blue, int[] combinedLights, int combinedOverlay, boolean mulColor) {
      float[] afloat = new float[]{colorMuls[0], colorMuls[1], colorMuls[2], colorMuls[3]};
      int[] aint = new int[]{combinedLights[0], combinedLights[1], combinedLights[2], combinedLights[3]};
      int[] aint1 = quad.getVertices();
      Vec3i vec3i = quad.getDirection().getNormal();
      Matrix4f matrix4f = poseEntry.pose();
      Vector3f vector3f = poseEntry.normal().transform(new Vector3f((float)vec3i.getX(), (float)vec3i.getY(), (float)vec3i.getZ()));
      int i = 8;
      int j = aint1.length / 8;

      try (MemoryStack memorystack = MemoryStack.stackPush()) {
         ByteBuffer bytebuffer = memorystack.malloc(DefaultVertexFormat.BLOCK.getVertexSize());
         IntBuffer intbuffer = bytebuffer.asIntBuffer();

         for(int k = 0; k < j; ++k) {
            intbuffer.clear();
            intbuffer.put(aint1, k * 8, 8);
            float f = bytebuffer.getFloat(0);
            float f1 = bytebuffer.getFloat(4);
            float f2 = bytebuffer.getFloat(8);
            float f3;
            float f4;
            float f5;
            if (mulColor) {
               float f6 = (float)(bytebuffer.get(12) & 255) / 255.0F;
               float f7 = (float)(bytebuffer.get(13) & 255) / 255.0F;
               float f8 = (float)(bytebuffer.get(14) & 255) / 255.0F;
               f3 = f6 * afloat[k] * red;
               f4 = f7 * afloat[k] * green;
               f5 = f8 * afloat[k] * blue;
            } else {
               f3 = afloat[k] * red;
               f4 = afloat[k] * green;
               f5 = afloat[k] * blue;
            }

            int l = aint[k];
            float f9 = bytebuffer.getFloat(16);
            float f10 = bytebuffer.getFloat(20);
            Vector4f vector4f = matrix4f.transform(new Vector4f(f, f1, f2, 1.0F));
            this.vertex(vector4f.x(), vector4f.y(), vector4f.z(), f3, f4, f5, 1.0F, f9, f10, combinedOverlay, l, vector3f.x(), vector3f.y(), vector3f.z());
         }
      }

   }

   default VertexConsumer vertex(Matrix4f matrix, float x, float y, float z) {
      Vector4f vector4f = matrix.transform(new Vector4f(x, y, z, 1.0F));
      return this.vertex((double)vector4f.x(), (double)vector4f.y(), (double)vector4f.z());
   }

   default VertexConsumer normal(Matrix3f matrix, float x, float y, float z) {
      Vector3f vector3f = matrix.transform(new Vector3f(x, y, z));
      return this.normal(vector3f.x(), vector3f.y(), vector3f.z());
   }
}

package com.mojang.blaze3d.vertex;

import net.minecraft.core.Direction;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

@OnlyIn(Dist.CLIENT)
public class SheetedDecalTextureGenerator extends DefaultedVertexConsumer {
   private final VertexConsumer delegate;
   private final Matrix4f cameraInversePose;
   private final Matrix3f normalInversePose;
   private final float textureScale;
   private float x;
   private float y;
   private float z;
   private int overlayU;
   private int overlayV;
   private int lightCoords;
   private float nx;
   private float ny;
   private float nz;

   public SheetedDecalTextureGenerator(VertexConsumer delegate, Matrix4f cameraPose, Matrix3f normalPose, float textureScale) {
      this.delegate = delegate;
      this.cameraInversePose = (new Matrix4f(cameraPose)).invert();
      this.normalInversePose = (new Matrix3f(normalPose)).invert();
      this.textureScale = textureScale;
      this.resetState();
   }

   private void resetState() {
      this.x = 0.0F;
      this.y = 0.0F;
      this.z = 0.0F;
      this.overlayU = 0;
      this.overlayV = 10;
      this.lightCoords = 15728880;
      this.nx = 0.0F;
      this.ny = 1.0F;
      this.nz = 0.0F;
   }

   public void endVertex() {
      Vector3f vector3f = this.normalInversePose.transform(new Vector3f(this.nx, this.ny, this.nz));
      Direction direction = Direction.getNearest(vector3f.x(), vector3f.y(), vector3f.z());
      Vector4f vector4f = this.cameraInversePose.transform(new Vector4f(this.x, this.y, this.z, 1.0F));
      vector4f.rotateY((float)Math.PI);
      vector4f.rotateX((-(float)Math.PI / 2F));
      vector4f.rotate(direction.getRotation());
      float f = -vector4f.x() * this.textureScale;
      float f1 = -vector4f.y() * this.textureScale;
      this.delegate.vertex((double)this.x, (double)this.y, (double)this.z).color(1.0F, 1.0F, 1.0F, 1.0F).uv(f, f1).overlayCoords(this.overlayU, this.overlayV).uv2(this.lightCoords).normal(this.nx, this.ny, this.nz).endVertex();
      this.resetState();
   }

   public VertexConsumer vertex(double x, double y, double z) {
      this.x = (float)x;
      this.y = (float)y;
      this.z = (float)z;
      return this;
   }

   public VertexConsumer color(int red, int green, int blue, int alpha) {
      return this;
   }

   public VertexConsumer uv(float u, float v) {
      return this;
   }

   public VertexConsumer overlayCoords(int u, int v) {
      this.overlayU = u;
      this.overlayV = v;
      return this;
   }

   public VertexConsumer uv2(int u, int v) {
      this.lightCoords = u | v << 16;
      return this;
   }

   public VertexConsumer normal(float x, float y, float z) {
      this.nx = x;
      this.ny = y;
      this.nz = z;
      return this;
   }
}

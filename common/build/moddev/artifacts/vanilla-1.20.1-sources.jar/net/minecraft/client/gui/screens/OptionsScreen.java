package net.minecraft.client.gui.screens;

import java.util.function.Supplier;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.LockIconButton;
import net.minecraft.client.gui.layouts.FrameLayout;
import net.minecraft.client.gui.layouts.GridLayout;
import net.minecraft.client.gui.layouts.LayoutElement;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.layouts.SpacerElement;
import net.minecraft.client.gui.screens.controls.ControlsScreen;
import net.minecraft.client.gui.screens.packs.PackSelectionScreen;
import net.minecraft.client.gui.screens.telemetry.TelemetryInfoScreen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ServerboundChangeDifficultyPacket;
import net.minecraft.network.protocol.game.ServerboundLockDifficultyPacket;
import net.minecraft.server.packs.repository.PackRepository;
import net.minecraft.world.Difficulty;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class OptionsScreen extends Screen {
   private static final Component SKIN_CUSTOMIZATION = Component.translatable("options.skinCustomisation");
   private static final Component SOUNDS = Component.translatable("options.sounds");
   private static final Component VIDEO = Component.translatable("options.video");
   private static final Component CONTROLS = Component.translatable("options.controls");
   private static final Component LANGUAGE = Component.translatable("options.language");
   private static final Component CHAT = Component.translatable("options.chat.title");
   private static final Component RESOURCEPACK = Component.translatable("options.resourcepack");
   private static final Component ACCESSIBILITY = Component.translatable("options.accessibility.title");
   private static final Component TELEMETRY = Component.translatable("options.telemetry");
   private static final Component CREDITS_AND_ATTRIBUTION = Component.translatable("options.credits_and_attribution");
   private static final int COLUMNS = 2;
   private final Screen lastScreen;
   private final Options options;
   private CycleButton<Difficulty> difficultyButton;
   private LockIconButton lockButton;

   public OptionsScreen(Screen lastScreen, Options options) {
      super(Component.translatable("options.title"));
      this.lastScreen = lastScreen;
      this.options = options;
   }

   protected void init() {
      GridLayout gridlayout = new GridLayout();
      gridlayout.defaultCellSetting().paddingHorizontal(5).paddingBottom(4).alignHorizontallyCenter();
      GridLayout.RowHelper gridlayout$rowhelper = gridlayout.createRowHelper(2);
      gridlayout$rowhelper.addChild(this.options.fov().createButton(this.minecraft.options, 0, 0, 150));
      gridlayout$rowhelper.addChild(this.createOnlineButton());
      gridlayout$rowhelper.addChild(SpacerElement.height(26), 2);
      gridlayout$rowhelper.addChild(this.openScreenButton(SKIN_CUSTOMIZATION, () -> {
         return new SkinCustomizationScreen(this, this.options);
      }));
      gridlayout$rowhelper.addChild(this.openScreenButton(SOUNDS, () -> {
         return new SoundOptionsScreen(this, this.options);
      }));
      gridlayout$rowhelper.addChild(this.openScreenButton(VIDEO, () -> {
         return new VideoSettingsScreen(this, this.options);
      }));
      gridlayout$rowhelper.addChild(this.openScreenButton(CONTROLS, () -> {
         return new ControlsScreen(this, this.options);
      }));
      gridlayout$rowhelper.addChild(this.openScreenButton(LANGUAGE, () -> {
         return new LanguageSelectScreen(this, this.options, this.minecraft.getLanguageManager());
      }));
      gridlayout$rowhelper.addChild(this.openScreenButton(CHAT, () -> {
         return new ChatOptionsScreen(this, this.options);
      }));
      gridlayout$rowhelper.addChild(this.openScreenButton(RESOURCEPACK, () -> {
         return new PackSelectionScreen(this.minecraft.getResourcePackRepository(), this::applyPacks, this.minecraft.getResourcePackDirectory(), Component.translatable("resourcePack.title"));
      }));
      gridlayout$rowhelper.addChild(this.openScreenButton(ACCESSIBILITY, () -> {
         return new AccessibilityOptionsScreen(this, this.options);
      }));
      gridlayout$rowhelper.addChild(this.openScreenButton(TELEMETRY, () -> {
         return new TelemetryInfoScreen(this, this.options);
      }));
      gridlayout$rowhelper.addChild(this.openScreenButton(CREDITS_AND_ATTRIBUTION, () -> {
         return new CreditsAndAttributionScreen(this);
      }));
      gridlayout$rowhelper.addChild(Button.builder(CommonComponents.GUI_DONE, (p_280809_) -> {
         this.minecraft.setScreen(this.lastScreen);
      }).width(200).build(), 2, gridlayout$rowhelper.newCellSettings().paddingTop(6));
      gridlayout.arrangeElements();
      FrameLayout.alignInRectangle(gridlayout, 0, this.height / 6 - 12, this.width, this.height, 0.5F, 0.0F);
      gridlayout.visitWidgets(this::addRenderableWidget);
   }

   private void applyPacks(PackRepository packs) {
      this.options.updateResourcePacks(packs);
      this.minecraft.setScreen(this);
   }

   private LayoutElement createOnlineButton() {
      if (this.minecraft.level != null && this.minecraft.hasSingleplayerServer()) {
         this.difficultyButton = createDifficultyButton(0, 0, "options.difficulty", this.minecraft);
         if (!this.minecraft.level.getLevelData().isHardcore()) {
            this.lockButton = new LockIconButton(0, 0, (p_280806_) -> {
               this.minecraft.setScreen(new ConfirmScreen(this::lockCallback, Component.translatable("difficulty.lock.title"), Component.translatable("difficulty.lock.question", this.minecraft.level.getLevelData().getDifficulty().getDisplayName())));
            });
            this.difficultyButton.setWidth(this.difficultyButton.getWidth() - this.lockButton.getWidth());
            this.lockButton.setLocked(this.minecraft.level.getLevelData().isDifficultyLocked());
            this.lockButton.active = !this.lockButton.isLocked();
            this.difficultyButton.active = !this.lockButton.isLocked();
            LinearLayout linearlayout = new LinearLayout(150, 0, LinearLayout.Orientation.HORIZONTAL);
            linearlayout.addChild(this.difficultyButton);
            linearlayout.addChild(this.lockButton);
            return linearlayout;
         } else {
            this.difficultyButton.active = false;
            return this.difficultyButton;
         }
      } else {
         return Button.builder(Component.translatable("options.online"), (p_280805_) -> {
            this.minecraft.setScreen(OnlineOptionsScreen.createOnlineOptionsScreen(this.minecraft, this, this.options));
         }).bounds(this.width / 2 + 5, this.height / 6 - 12 + 24, 150, 20).build();
      }
   }

   public static CycleButton<Difficulty> createDifficultyButton(int x, int y, String translationKey, Minecraft minecraft) {
      return CycleButton.builder(Difficulty::getDisplayName).withValues(Difficulty.values()).withInitialValue(minecraft.level.getDifficulty()).create(x, y, 150, 20, Component.translatable(translationKey), (p_193854_, p_193855_) -> {
         minecraft.getConnection().send(new ServerboundChangeDifficultyPacket(p_193855_));
      });
   }

   private void lockCallback(boolean value) {
      this.minecraft.setScreen(this);
      if (value && this.minecraft.level != null) {
         this.minecraft.getConnection().send(new ServerboundLockDifficultyPacket(true));
         this.lockButton.setLocked(true);
         this.lockButton.active = false;
         this.difficultyButton.active = false;
      }

   }

   public void removed() {
      this.options.save();
   }

   /**
    * Renders the graphical user interface (GUI) element.
    *
    * @param guiGraphics the GuiGraphics object used for rendering.
    * @param mouseX      the x-coordinate of the mouse cursor.
    * @param mouseY      the y-coordinate of the mouse cursor.
    * @param partialTick the partial tick time.
    */
   public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
      this.renderBackground(guiGraphics);
      guiGraphics.drawCenteredString(this.font, this.title, this.width / 2, 15, 16777215);
      super.render(guiGraphics, mouseX, mouseY, partialTick);
   }

   private Button openScreenButton(Component text, Supplier<Screen> screenSupplier) {
      return Button.builder(text, (p_280808_) -> {
         this.minecraft.setScreen(screenSupplier.get());
      }).build();
   }
}
